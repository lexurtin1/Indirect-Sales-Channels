# Build log

One entry per build step. Newest first.

| Date | Step | Files changed | Open items |
| --- | --- | --- | --- |
| 2026-10-30 | 3: FFI data extraction | data/ffi/extracted/ffi.json, scripts/validate-ffi.mjs, docs/fund-flow-index.md | Report URLs; confirm Asia sector naming |
| 2026-10-30 | 3b: illustrative network data | scripts/generate-illustrative-network.mjs, data/network/illustrative-network.json, docs/network-flow-globe.md, docs/fund-flow-index.md | Real data release rules; suppression threshold |
